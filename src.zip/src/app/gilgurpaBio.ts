export class GilgurpaBio
{
  gilgurpaName : string;
  gilgurpaID: string;
}