export class Review
{
  route: string;
  leave: string;
  arrive: string;
}