import { Review } from "../../app/review";

export const SCHEDULE: Review[] = [
  {route: 'Union', leave: '7:00am', arrive: '8:15am'},
  {route: 'Union', leave: '8:15am', arrive: '9:30am'}
]